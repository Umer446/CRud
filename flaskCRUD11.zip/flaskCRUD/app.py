from flask import Flask,render_template,request,redirect
from models import db,UserModel,PostModel,CommentModel
 
app = Flask(__name__)
 
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///model.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False 
db.init_app(app)
 
@app.before_first_request
def create_table():
    db.create_all()
    
@app.route('/create' , methods = ['GET','POST'])
def create():   
    if request.method == 'GET':
        return render_template('createpage.html')
 
    if request.method == 'POST':

        first_name = request.form['first_name']
        last_name = request.form['last_name']
        email = request.form['email']
        
        users = UserModel(
            first_name=first_name,
            last_name=last_name,
            email=email,
          
        )
        db.session.add(users)
        db.session.commit()
        return redirect('/')
    
@app.route('/upload' , methods = ['GET','POST'])
def upload():   
    if request.method == 'GET':
        return render_template('createpost.html')
 
    if request.method == 'POST':

        title = request.form['title']
        desc = request.form['desc']
        
        uploads = PostModel(
            title=title,
            desc=desc,
        )
        db.session.add(uploads)
        db.session.commit()
        return redirect('/displayposts')    
 
 
@app.route('/')
def RetrieveList():
    users = UserModel.query.all()
    return render_template('datalist.html',users = users)

@app.route('/displayposts')
def displaypost():
    uploads = PostModel.query.all()
    return render_template('datalist2.html',uploads = uploads)

@app.route('/<int:id>/deletepost', methods=['GET','POST'])
def deletepost(id):
    uploads=PostModel.query.filter_by(id=id).first()
    if request.method == 'POST':
        if uploads:
            db.session.delete(uploads)
            db.session.commit()
            return redirect('/displayposts')
    return render_template('delete.html')
        
        
    

@app.route('/<int:id>/delete', methods=['GET','POST'])
def delete(id):
    users = UserModel.query.filter_by(id=id).first()
    if request.method== 'POST':
        if users :
               db.session.delete(users)
               db.session.commit()
               return redirect('/')
    return render_template('delete.html')
      
@app.route('/<int:id>/edit', methods=['GET','POST'])
def update(id):
    user = UserModel.query.filter_by(id=id).first()
    if request.method == 'POST':
         if user:
            db.session.delete(user)
            db.session.commit()
         first_name = request.form['first_name']
         last_name = request.form['last_name']
         email = request.form['email']
        
         user = UserModel(
            first_name=first_name,
            last_name=last_name,
            email=email,
          
        )
         db.session.add(user)
         db.session.commit()
         return redirect('/')
         
        
    return render_template('update.html',user = user)    

@app.route('/<int:id>/editpost', methods=['GET','POST'])
def updatepost(id):
    post = PostModel.query.filter_by(id=id).first()
    if request.method == 'POST':
         if post:
            db.session.delete(post)
            db.session.commit()
         title = request.form['title']
         desc = request.form['desc']
        
        
         post = PostModel(
            title=title,
            desc=desc,
           
          
        )
         db.session.add(post)
         db.session.commit()
         return redirect('/displayposts')
         
        
    return render_template('updatepost.html',post = post)    


@app.route('/addcomment', methods=['GET','POST'])
def addcomment():
    if request.method == 'GET':
        return render_template('comment.html')
 
    if request.method == 'POST':

        comment = request.form['comment']
        email = request.form['email']
        
        com = UserModel(
            comment=comment,
            
            email=email,
          
        )
        db.session.add(com)
        db.session.commit()

        return redirect('displaycomments')
    
@app.route('/displaycomments')
def displaycomments():
    comments = PostModel.query.all()
    return render_template('datalist2.html',comments = comments)
    


    
        
        
    
 
    


 
app.run(host='localhost', port=5000,debug=True)

