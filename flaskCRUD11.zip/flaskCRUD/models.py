from flask_sqlalchemy import SQLAlchemy
    
db =SQLAlchemy()
 
class UserModel(db.Model):
    __tablename__ = "users"
 
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String())
    last_name = db.Column(db.String())
    email = db.Column(db.String())  
  
    def __init__(self, first_name,last_name,email):
        self.first_name = first_name
        self.last_name = last_name
        self.email = email
        
    def __repr__(self):
        return f"{self.first_name}:{self.last_name}"
    
class PostModel(db.Model):
     __tablename__ = "post"
     
     
     id = db.Column(db.Integer, primary_key=True)
     title = db.Column(db.String())
     desc = db.Column(db.String())
     
     comments = db.relationship('CommentModel', backref='post') 

     def __init__(self,title,desc):
        self.title = title
        self.desc = desc
        
      
        
class CommentModel(db.Model):   
    __tablename__ = "comment"
    
    
    id = db.Column(db.Integer, primary_key=True)
    comment = db.Column(db.String())
    post_id = db.Column(db.Integer, db.ForeignKey('post.id',ondelete="CASCADE"), nullable=False)
    
  
     
     
    def __init__(self,comment):
        self.comment = comment
       


    
        

        
       
     
     
     
     
     

